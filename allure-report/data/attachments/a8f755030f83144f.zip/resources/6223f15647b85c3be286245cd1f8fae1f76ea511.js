// cookie-consent.js

// Create style element
const style = document.createElement('style');
style.textContent = `
  .overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5);
    display: none;
    justify-content: center;
    align-items: center;
    z-index: 1000;
  }
  .cookie-dialog {
    background-color: #f0f0f0;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
    text-align: center;
    max-width: 400px;
  }
  .cookie-dialog h2 {
    color: #333;
    margin-bottom: 15px;
  }
  .cookie-dialog p {
    color: #666;
    margin-bottom: 20px;
  }
  .cookie-dialog button {
    padding: 10px 20px;
    margin: 0 10px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-weight: bold;
    transition: background-color 0.3s;
  }
  .accept-btn {
    background-color: #4CAF50;
    color: white;
  }
  .accept-btn:hover {
    background-color: #45a049;
  }
  .reject-btn {
    background-color: #f44336;
    color: white;
  }
  .reject-btn:hover {
    background-color: #da190b;
  }
  .blur {
    filter: blur(5px);
    transition: filter 0.3s ease;
  }
`;
document.head.appendChild(style);

// Wrap the main content in a container
function wrapMainContent() {
  const mainContent = document.createElement('div');
  mainContent.id = 'main-content';
  
  // Move all body children into the new container
  while (document.body.firstChild) {
    mainContent.appendChild(document.body.firstChild);
  }
  
  document.body.appendChild(mainContent);
}

// Create overlay and dialog elements
const overlay = document.createElement('div');
overlay.className = 'overlay';
overlay.innerHTML = `
  <div class="cookie-dialog">
    <h2>Cookie Consent</h2>
    <p>We use cookies to enhance your browsing experience. Do you accept our use of cookies?</p>
    <button class="accept-btn">Accept</button>
    <button class="reject-btn">Reject</button>
  </div>
`;

// Function to show the dialog
function showDialog() {
  const mainContent = document.getElementById('main-content');
  mainContent.classList.add('blur');
  overlay.style.display = 'flex';
}

// Function to hide the dialog
function hideDialog() {
  const mainContent = document.getElementById('main-content');
  mainContent.classList.remove('blur');
  overlay.style.display = 'none';
}

// Event listeners for buttons
overlay.querySelector('.accept-btn').addEventListener('click', () => {
  console.log('Cookies accepted');
  hideDialog();
});

overlay.querySelector('.reject-btn').addEventListener('click', () => {
  console.log('Cookies rejected');
  hideDialog();
});

// Initialize the cookie consent functionality
function initCookieConsent() {
  wrapMainContent();
  document.body.appendChild(overlay);
  setTimeout(showDialog, 10000);
}

// Run the initialization when the DOM is fully loaded
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initCookieConsent);
} else {
  initCookieConsent();
}